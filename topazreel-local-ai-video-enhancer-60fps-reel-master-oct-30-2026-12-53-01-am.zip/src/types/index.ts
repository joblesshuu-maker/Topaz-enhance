/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface EnhancementSettings {
  // Topaz-grade Neural Enhancement
  sharpness: number;         // 0 - 200 (Default: 75)
  denoise: number;           // 0 - 100 (Default: 30)
  detailRecovery: number;    // 0 - 100 (Default: 60)
  contrastLift: number;      // 0 - 100 (Default: 20)
  vibrance: number;          // 0 - 100 (Default: 15)
  antiBandingDither: number; // 0 - 20 (Default: 8 - Instagram compression shield)
  skinProtection: boolean;   // Protect natural skin tones from over-sharpening
  targetFps: number;         // 30 or 60 (Default: 60 FPS lock)
  upscaleFactor: number;     // 1, 1.5, 2 (e.g. 1080p to 4K)
}

export type ComparisonMode = 'split' | 'side-by-side' | 'enhanced-only' | 'original-only';

export interface ReelPreset {
  id: string;
  name: string;
  badge: string;
  platform: 'Instagram' | 'TikTok' | 'YouTube' | 'Cinema' | 'Portrait';
  targetResolution: { width: number; height: number };
  targetFps: number;
  bitrateMbps: number;
  antiCompressionProfile: string;
  description: string;
  settings: EnhancementSettings;
  recommendations: string[];
}

export interface PermissionStatusItem {
  id: string;
  name: string;
  description: string;
  status: 'granted' | 'denied' | 'prompt' | 'unsupported';
  icon: string;
}

export interface ExportProgress {
  isExporting: boolean;
  currentFrame: number;
  totalFrames: number;
  percentage: number;
  fps: number;
  elapsedSeconds: number;
  statusText: string;
  outputBlobUrl: string | null;
  outputSizeMb: number;
}
