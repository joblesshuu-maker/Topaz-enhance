/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ReelPreset } from '../types';

export const REEL_PRESETS: ReelPreset[] = [
  {
    id: 'instagram-reel-master',
    name: 'Instagram Reel Master',
    badge: 'Recommended',
    platform: 'Instagram',
    targetResolution: { width: 1080, height: 1920 },
    targetFps: 60,
    bitrateMbps: 18.5,
    antiCompressionProfile: 'IG-CBR 18.5M · Rec.709 · Micro-Dither',
    description: 'Calibrated to bypass Instagram server re-encoding triggers while retaining 60 FPS crisp clarity.',
    recommendations: [
      'Enable "Upload at highest quality" in Instagram Settings > Account > Data usage',
      'Target exactly 1080x1920 (9:16 vertical)',
      'Keep frame rate locked at solid 60 FPS to avoid mobile stutter',
      'Micro-dither is pre-enabled to prevent Instagram sky/skin color banding'
    ],
    settings: {
      sharpness: 80,
      denoise: 30,
      detailRecovery: 65,
      contrastLift: 18,
      vibrance: 16,
      antiBandingDither: 8,
      skinProtection: true,
      targetFps: 60,
      upscaleFactor: 1
    }
  },
  {
    id: 'tiktok-crisp-hd',
    name: 'TikTok Ultra HD',
    badge: 'High Contrast',
    platform: 'TikTok',
    targetResolution: { width: 1080, height: 1920 },
    targetFps: 60,
    bitrateMbps: 16.0,
    antiCompressionProfile: 'ByteDance H.264 · 16Mbps · Edge-Boost',
    description: 'Optimized for TikTok dynamic feed with punchy edge contrast and vibrant color rendering.',
    recommendations: [
      'Keep under 3 minutes for maximum bitrate allocation',
      'Contrast and edge sharpness elevated for rapid scrolling feed readability',
      'Turn on "Allow high-quality uploads" on final TikTok post screen'
    ],
    settings: {
      sharpness: 90,
      denoise: 25,
      detailRecovery: 70,
      contrastLift: 26,
      vibrance: 22,
      antiBandingDither: 6,
      skinProtection: true,
      targetFps: 60,
      upscaleFactor: 1
    }
  },
  {
    id: 'portrait-beauty-clarity',
    name: 'Face & Skin Clarity',
    badge: 'Portrait Pro',
    platform: 'Portrait',
    targetResolution: { width: 1080, height: 1920 },
    targetFps: 60,
    bitrateMbps: 20.0,
    antiCompressionProfile: 'Bilateral Skin · Eye Pop · 20Mbps',
    description: 'Topaz-style facial recovery: smooths skin blemishes while super-sharpening eyes, eyelashes, and hair strands.',
    recommendations: [
      'Ideal for talking head reels, fashion shoots, fitness and selfies',
      'Smart bilateral skin mask prevents harsh pores while maintaining natural skin pores'
    ],
    settings: {
      sharpness: 70,
      denoise: 45,
      detailRecovery: 80,
      contrastLift: 12,
      vibrance: 14,
      antiBandingDither: 10,
      skinProtection: true,
      targetFps: 60,
      upscaleFactor: 1
    }
  },
  {
    id: 'youtube-shorts-4k',
    name: 'YouTube Shorts 4K',
    badge: 'Maximum Detail',
    platform: 'YouTube',
    targetResolution: { width: 2160, height: 3840 },
    targetFps: 60,
    bitrateMbps: 35.0,
    antiCompressionProfile: 'VP9/AV1 Target · 35Mbps · 4K Super-Res',
    description: '4K vertical super-resolution for YouTube Shorts which gives VP9/AV1 high-tier codec allocation on YouTube servers.',
    recommendations: [
      'YouTube grants high-tier VP9/AV1 codec when vertical video is 2K or 4K',
      'Results in crystal clear playback on tablet, PC, and flagship phone screens'
    ],
    settings: {
      sharpness: 85,
      denoise: 20,
      detailRecovery: 75,
      contrastLift: 15,
      vibrance: 18,
      antiBandingDither: 5,
      skinProtection: false,
      targetFps: 60,
      upscaleFactor: 2
    }
  },
  {
    id: 'night-denoise-recover',
    name: 'Low-Light Clean & Dynamic',
    badge: 'Noise Removal',
    platform: 'Cinema',
    targetResolution: { width: 1080, height: 1920 },
    targetFps: 60,
    bitrateMbps: 22.0,
    antiCompressionProfile: 'Chroma Clean · Shadow Lift · 22Mbps',
    description: 'Cleans up noisy sensor grain in dark bars, nightclubs, or night streets, and boosts dynamic range.',
    recommendations: [
      'Recovers crushed shadow details without blowing out neon lights or streetlamps',
      'Removes multicolored chromatic digital sensor noise'
    ],
    settings: {
      sharpness: 65,
      denoise: 60,
      detailRecovery: 50,
      contrastLift: 30,
      vibrance: 15,
      antiBandingDither: 12,
      skinProtection: true,
      targetFps: 60,
      upscaleFactor: 1
    }
  }
];
