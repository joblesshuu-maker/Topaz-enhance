/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { TopBar } from './components/TopBar';
import { VideoWorkspace } from './components/VideoWorkspace';
import { ControlsPanel } from './components/ControlsPanel';
import { PresetSelector } from './components/PresetSelector';
import { PermissionsPanel } from './components/PermissionsPanel';
import { ApkInstallModal } from './components/ApkInstallModal';
import { ExportModal } from './components/ExportModal';
import { REEL_PRESETS } from './data/presets';
import { EnhancementSettings, ComparisonMode, ReelPreset } from './types';
import { SAMPLE_CLIPS } from './utils/sampleVideos';

export default function App() {
  const [activeTab, setActiveTab] = useState<'workspace' | 'presets' | 'permissions' | 'apk'>('workspace');
  const [activePreset, setActivePreset] = useState<ReelPreset>(REEL_PRESETS[0]);
  const [settings, setSettings] = useState<EnhancementSettings>(REEL_PRESETS[0].settings);
  // Default to 100% FULL SCREEN Enhanced mode so sharpening applies to the whole screen
  const [comparisonMode, setComparisonMode] = useState<ComparisonMode>('enhanced-only');
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isControlsCollapsed, setIsControlsCollapsed] = useState<boolean>(false);

  // Video and Canvas DOM refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Video source state
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [videoFileName, setVideoFileName] = useState<string>('Portrait Sample Reel (9:16)');
  const [videoFileSize, setVideoFileSize] = useState<string>('Demo 60FPS');

  // Initialize sample video on first mount
  useEffect(() => {
    let isMounted = true;
    const initSample = async () => {
      try {
        const tempCanvas = document.createElement('canvas');
        const url = await SAMPLE_CLIPS[0].generateCanvasVideo(tempCanvas, 6);
        if (isMounted) {
          setVideoSrc(url);
        }
      } catch (e) {
        console.error('Failed to init sample clip:', e);
      }
    };
    initSample();
    return () => { isMounted = false; };
  }, []);

  // Update settings handler
  const handleUpdateSettings = (newSettings: Partial<EnhancementSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  // Reset to active preset settings
  const handleResetSettings = () => {
    setSettings(activePreset.settings);
  };

  // Select a preset
  const handleSelectPreset = (preset: ReelPreset) => {
    setActivePreset(preset);
    setSettings(preset.settings);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0B0F17] text-slate-100 overflow-hidden">
      {/* 3-Zone Top Bar Contract */}
      <TopBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenExport={() => setIsExportModalOpen(true)}
        isProcessing={false}
      />

      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden relative flex">
        {activeTab === 'workspace' && (
          <div className="flex-1 flex flex-col lg:flex-row h-full overflow-hidden">
            {/* Center Video Workspace */}
            <div className="flex-1 h-full min-w-0">
              <VideoWorkspace
                settings={settings}
                onUpdateSettings={handleUpdateSettings}
                comparisonMode={comparisonMode}
                setComparisonMode={setComparisonMode}
                videoRef={videoRef}
                canvasRef={canvasRef}
                videoSrc={videoSrc}
                setVideoSrc={setVideoSrc}
                videoFileName={videoFileName}
                setVideoFileName={setVideoFileName}
                videoFileSize={videoFileSize}
                setVideoFileSize={setVideoFileSize}
                activePresetName={activePreset.name}
                isControlsCollapsed={isControlsCollapsed}
                onToggleControls={() => setIsControlsCollapsed(!isControlsCollapsed)}
              />
            </div>

            {/* Right Controls Panel (Collapsible for 100% full-screen view) */}
            {!isControlsCollapsed && (
              <ControlsPanel
                settings={settings}
                onUpdateSettings={handleUpdateSettings}
                onReset={handleResetSettings}
                activePresetName={activePreset.name}
                onClose={() => setIsControlsCollapsed(true)}
              />
            )}
          </div>
        )}

        {activeTab === 'presets' && (
          <div className="flex-1 h-full overflow-y-auto">
            <PresetSelector
              activePresetId={activePreset.id}
              onSelectPreset={handleSelectPreset}
              onContinueToStudio={() => setActiveTab('workspace')}
            />
          </div>
        )}

        {activeTab === 'permissions' && (
          <div className="flex-1 h-full overflow-y-auto">
            <PermissionsPanel />
          </div>
        )}

        {activeTab === 'apk' && (
          <div className="flex-1 h-full overflow-y-auto">
            <ApkInstallModal />
          </div>
        )}
      </main>

      {/* Export 60 FPS Anti-Compression Modal */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        preset={activePreset}
        settings={settings}
        videoElement={videoRef.current}
      />
    </div>
  );
}
