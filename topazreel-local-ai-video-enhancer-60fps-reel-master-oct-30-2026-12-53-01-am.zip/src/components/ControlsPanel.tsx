/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Sliders, Sparkles, Shield, Zap, RotateCcw, Info } from 'lucide-react';
import { EnhancementSettings } from '../types';

interface ControlsPanelProps {
  settings: EnhancementSettings;
  onUpdateSettings: (newSettings: Partial<EnhancementSettings>) => void;
  onReset: () => void;
  activePresetName: string;
  onClose?: () => void;
}

export const ControlsPanel: React.FC<ControlsPanelProps> = ({
  settings,
  onUpdateSettings,
  onReset,
  activePresetName,
  onClose
}) => {
  return (
    <aside className="w-80 flex flex-col h-full border-l border-slate-800 bg-[#0E1422] select-none overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3.5 border-b border-slate-800/80 bg-slate-950/40">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-cyan-400" />
          <h2 className="text-xs font-semibold text-white tracking-wide uppercase">
            Topaz Neural Pipeline
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onReset}
            className="flex items-center gap-1 text-[11px] font-medium text-slate-400 hover:text-cyan-400 transition-colors"
            title="Reset to Preset Defaults"
          >
            <RotateCcw className="w-3 h-3" />
            Reset
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800"
              title="Collapse Panel (Full-Screen Video View)"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      <div className="p-4 space-y-5 flex-1">
        {/* Preset Context */}
        <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Active Profile</span>
            <span className="font-semibold text-cyan-300">{activePresetName}</span>
          </div>
          <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500 font-mono">
            <span>Target Output</span>
            <span>1080x1920 · 60.0 FPS</span>
          </div>
        </div>

        {/* 60 FPS Framerate Lock Guarantee */}
        <div className="p-3 rounded-lg bg-cyan-950/30 border border-cyan-800/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-cyan-400" />
              <div>
                <div className="text-xs font-semibold text-cyan-200">60 FPS Smooth Lock</div>
                <div className="text-[10px] text-cyan-400/80">Guaranteed 0 dropped frames</div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.targetFps === 60}
                onChange={(e) => onUpdateSettings({ targetFps: e.target.checked ? 60 : 30 })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500"></div>
            </label>
          </div>
        </div>

        {/* Sliders Group */}
        <div className="space-y-4">
          {/* Neural Sharpness */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-300">Neural Sharpness</span>
              <span className="font-mono text-cyan-400 tabular-nums">{settings.sharpness}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={200}
              value={settings.sharpness}
              onChange={(e) => onUpdateSettings({ sharpness: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
            />
            <p className="text-[10px] text-slate-500">
              Laplacian high-pass filter with halo-suppression gate.
            </p>
          </div>

          {/* Bilateral Noise Reduction */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-300">Noise Reduction (Denoise)</span>
              <span className="font-mono text-cyan-400 tabular-nums">{settings.denoise}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={settings.denoise}
              onChange={(e) => onUpdateSettings({ denoise: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
            />
            <p className="text-[10px] text-slate-500">
              Edge-preserving bilateral smoothing for low-light noise.
            </p>
          </div>

          {/* High-Frequency Detail Recovery */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-300">Detail &amp; Texture Recovery</span>
              <span className="font-mono text-cyan-400 tabular-nums">{settings.detailRecovery}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={settings.detailRecovery}
              onChange={(e) => onUpdateSettings({ detailRecovery: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
            />
            <p className="text-[10px] text-slate-500">
              Restores eyelashes, hair strands, and fabric weaves.
            </p>
          </div>

          {/* Adaptive Dynamic Contrast Lift */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-300">Dynamic Contrast Lift</span>
              <span className="font-mono text-cyan-400 tabular-nums">{settings.contrastLift}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={settings.contrastLift}
              onChange={(e) => onUpdateSettings({ contrastLift: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
            />
            <p className="text-[10px] text-slate-500">
              CLAHE tone-curve lifts dark shadows without clipping highlights.
            </p>
          </div>

          {/* Vibrance & Color Pop */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-300">Vibrance (Gamut Lift)</span>
              <span className="font-mono text-cyan-400 tabular-nums">{settings.vibrance}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={settings.vibrance}
              onChange={(e) => onUpdateSettings({ vibrance: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
            />
          </div>

          {/* Anti-Banding Micro-Dither (Instagram Recompression Shield) */}
          <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-cyan-400" />
                <span className="font-medium text-slate-300">Anti-Banding Dither</span>
              </div>
              <span className="font-mono text-cyan-400 tabular-nums">{settings.antiBandingDither}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={20}
              value={settings.antiBandingDither}
              onChange={(e) => onUpdateSettings({ antiBandingDither: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex items-start gap-1 text-[10px] text-cyan-400/90 leading-tight">
              <Info className="w-3 h-3 shrink-0 mt-0.5" />
              <span>
                Prevents Instagram &amp; TikTok compression algorithms from flattening smooth gradients into ugly banding blocks.
              </span>
            </div>
          </div>

          {/* Skin Protection Mask */}
          <div className="pt-2 border-t border-slate-800/80">
            <label className="flex items-center justify-between cursor-pointer">
              <div className="flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                <div>
                  <div className="text-xs font-medium text-slate-200">Face &amp; Skin Protection</div>
                  <div className="text-[10px] text-slate-500">Smooths skin while keeping eyes &amp; hair razor sharp</div>
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.skinProtection}
                onChange={(e) => onUpdateSettings({ skinProtection: e.target.checked })}
                className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-cyan-500 focus:ring-0"
              />
            </label>
          </div>
        </div>
      </div>
    </aside>
  );
};
