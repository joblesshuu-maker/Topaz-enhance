/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Check, ShieldCheck, Film, Sparkles, Smartphone, ArrowRight } from 'lucide-react';
import { ReelPreset } from '../types';
import { REEL_PRESETS } from '../data/presets';

interface PresetSelectorProps {
  activePresetId: string;
  onSelectPreset: (preset: ReelPreset) => void;
  onContinueToStudio: () => void;
}

export const PresetSelector: React.FC<PresetSelectorProps> = ({
  activePresetId,
  onSelectPreset,
  onContinueToStudio
}) => {
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      {/* Editorial Header */}
      <div className="mb-8">
        <h1 className="font-display text-2xl font-bold tracking-tight text-white">
          Reel Anti-Compression Presets
        </h1>
        <p className="mt-1 text-sm text-slate-400 max-w-2xl text-balance">
          Calibrated mathematical profiles designed to bypass aggressive social media transcoding algorithms and deliver crisp 60 FPS HD output.
        </p>
      </div>

      {/* Preset Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
        {REEL_PRESETS.map((preset) => {
          const isSelected = preset.id === activePresetId;
          return (
            <div
              key={preset.id}
              onClick={() => onSelectPreset(preset)}
              className={`relative flex flex-col justify-between p-5 rounded-xl border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-gradient-to-b from-cyan-950/40 to-slate-900 border-cyan-500/80 shadow-lg shadow-cyan-950/50'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
              }`}
            >
              <div>
                {/* Platform & Badge Header */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-xs font-semibold text-slate-400">
                    {preset.platform}
                  </span>
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                    {preset.badge}
                  </span>
                </div>

                {/* Preset Title */}
                <h3 className="text-base font-semibold text-white mb-1.5 flex items-center justify-between">
                  <span>{preset.name}</span>
                  {isSelected && <Check className="w-4 h-4 text-cyan-400 shrink-0" />}
                </h3>

                <p className="text-xs text-slate-400 mb-4 line-clamp-2">
                  {preset.description}
                </p>

                {/* Technical Metric Specs */}
                <div className="space-y-1.5 py-3 border-t border-slate-800/80 text-xs">
                  <div className="flex items-center justify-between text-slate-400 font-mono">
                    <span>Resolution</span>
                    <span className="text-slate-200">
                      {preset.targetResolution.width}x{preset.targetResolution.height} (9:16)
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400 font-mono">
                    <span>Target Framerate</span>
                    <span className="text-emerald-400 font-semibold">
                      {preset.targetFps}.0 FPS Locked
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400 font-mono">
                    <span>Sweet Spot Bitrate</span>
                    <span className="text-cyan-300 font-semibold">
                      {preset.bitrateMbps} Mbps
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between">
                <span className="text-[11px] text-slate-500 font-mono truncate max-w-[200px]">
                  {preset.antiCompressionProfile}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectPreset(preset);
                    onContinueToStudio();
                  }}
                  className={`text-xs font-semibold px-3 py-1.5 rounded transition-colors ${
                    isSelected
                      ? 'bg-cyan-500 text-slate-950 hover:bg-cyan-400'
                      : 'bg-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  {isSelected ? 'Active' : 'Apply'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Reel Anti-Compression Guide & Knowledge Base */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 to-slate-950 border border-slate-800">
        <div className="flex items-center gap-2 mb-3">
          <ShieldCheck className="w-5 h-5 text-cyan-400" />
          <h2 className="text-base font-semibold text-white">
            How TopazReel Prevents Instagram Compression
          </h2>
        </div>
        <p className="text-xs text-slate-400 mb-5 leading-relaxed">
          Instagram, TikTok, and YouTube use automated transcoders that destroy video clarity if specific technical triggers are tripped. Here is how TopazReel bypasses them:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80">
            <div className="flex items-center gap-1.5 font-semibold text-slate-200 mb-1.5">
              <Film className="w-4 h-4 text-cyan-400" />
              1. The 18.5 Mbps Sweet Spot
            </div>
            <p className="text-slate-400 leading-normal">
              Videos over 25 Mbps trigger Instagram's aggressive CRF 28 encoder, crushing faces into pixel soup. TopazReel targets 18.5 Mbps, the exact ceiling for high-quality passthrough.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80">
            <div className="flex items-center gap-1.5 font-semibold text-slate-200 mb-1.5">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              2. Anti-Banding Micro-Dither
            </div>
            <p className="text-slate-400 leading-normal">
              Social platforms truncate smooth color gradients (sky, skin) into ugly color blocks. Our 0.8% micro-dither noise tricks the encoder into preserving continuous color transitions.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80">
            <div className="flex items-center gap-1.5 font-semibold text-slate-200 mb-1.5">
              <Smartphone className="w-4 h-4 text-emerald-400" />
              3. Guaranteed 60.0 FPS Lock
            </div>
            <p className="text-slate-400 leading-normal">
              We render frame-by-frame with zero frame drops so high-refresh smartphone screens (iPhone ProMotion 120Hz &amp; Android 90/120Hz) play buttery-smooth motion.
            </p>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between">
          <span className="text-xs text-slate-400">
            Tip: In Instagram App &rarr; Settings &rarr; Account &rarr; Data Usage &rarr; Toggle ON "Upload at highest quality".
          </span>
          <button
            onClick={onContinueToStudio}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors shrink-0"
          >
            Open in Studio
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
