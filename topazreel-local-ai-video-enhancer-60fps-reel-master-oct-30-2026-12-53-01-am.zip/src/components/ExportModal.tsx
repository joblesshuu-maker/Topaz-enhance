/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import confetti from 'canvas-confetti';
import { X, Download, Film, Zap, CheckCircle2, ShieldCheck, Sparkles, Loader2, Play } from 'lucide-react';
import { ReelPreset, EnhancementSettings, ExportProgress } from '../types';
import { VideoExporter } from '../engine/videoExporter';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  preset: ReelPreset;
  settings: EnhancementSettings;
  videoElement: HTMLVideoElement | null;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  preset,
  settings,
  videoElement
}) => {
  const [exporter] = useState(() => new VideoExporter());
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [progress, setProgress] = useState<ExportProgress>({
    isExporting: false,
    currentFrame: 0,
    totalFrames: 0,
    percentage: 0,
    fps: 60,
    elapsedSeconds: 0,
    statusText: '',
    outputBlobUrl: null,
    outputSizeMb: 0
  });

  if (!isOpen) return null;

  const handleStartExport = async () => {
    if (!videoElement) {
      alert('Please wait for video to load before exporting.');
      return;
    }

    try {
      const outputUrl = await exporter.exportEnhancedVideo(
        videoElement,
        preset,
        settings,
        (prog) => setProgress(prog),
        previewCanvasRef.current
      );

      // Trigger celebratory confetti on completion
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch (err: unknown) {
      if ((err as Error)?.message !== 'Export cancelled by user') {
        console.error('Export error:', err);
        alert('Export failed. Please check browser hardware acceleration.');
      }
    }
  };

  const handleCancel = () => {
    exporter.cancel();
    setProgress((prev) => ({ ...prev, isExporting: false }));
  };

  const handleDownload = () => {
    if (progress.outputBlobUrl) {
      const a = document.createElement('a');
      a.href = progress.outputBlobUrl;
      const isMp4 = progress.outputBlobUrl.includes('mp4') || MediaRecorder.isTypeSupported('video/mp4');
      a.download = `TopazReel_60FPS_${preset.platform}_Crisp.${isMp4 ? 'mp4' : 'webm'}`;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => document.body.removeChild(a), 100);
    }
  };

  const handleCloseModal = () => {
    if (progress.isExporting) {
      exporter.cancel();
    }
    setProgress({
      isExporting: false,
      currentFrame: 0,
      totalFrames: 0,
      percentage: 0,
      fps: 60,
      elapsedSeconds: 0,
      statusText: '',
      outputBlobUrl: null,
      outputSizeMb: 0
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg rounded-2xl bg-[#0E1422] border border-slate-800 shadow-2xl p-6 text-slate-100 max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={handleCloseModal}
          disabled={progress.isExporting}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 disabled:opacity-30 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-2.5 mb-4">
          <div className="p-2 rounded-lg bg-cyan-950 border border-cyan-800/80">
            <Film className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <h2 className="font-display text-base font-bold text-white">
              Export Anti-Compression Reel
            </h2>
            <p className="text-xs text-slate-400">
              Guaranteed 60 FPS output · Calibrated for zero quality loss
            </p>
          </div>
        </div>

        {/* Export Spec Summary Card */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 space-y-2 mb-4 text-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span>Profile</span>
            <span className="font-semibold text-white">{preset.name}</span>
          </div>
          <div className="flex items-center justify-between text-slate-400 font-mono">
            <span>Target Resolution</span>
            <span className="text-slate-200">{preset.targetResolution.width} x {preset.targetResolution.height} (9:16)</span>
          </div>
          <div className="flex items-center justify-between text-slate-400 font-mono">
            <span>Framerate (FPS Lock)</span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <Zap className="w-3.5 h-3.5" />
              60.0 FPS Guaranteed (0 Dropped Frames)
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-400 font-mono">
            <span>Target Bitrate</span>
            <span className="text-cyan-300 font-semibold">{preset.bitrateMbps} Mbps (Sweet Spot)</span>
          </div>
          <div className="flex items-center justify-between text-slate-400 font-mono">
            <span>Anti-Banding Shield</span>
            <span className="text-slate-300">Active ({settings.antiBandingDither}% Dither)</span>
          </div>
        </div>

        {/* Live Encoding Preview or Output Player */}
        {progress.isExporting ? (
          <div className="space-y-4 my-4">
            {/* Live Video Render Canvas Monitor */}
            <div className="relative aspect-[9/16] max-h-56 mx-auto rounded-xl overflow-hidden border border-cyan-500/40 bg-black shadow-lg shadow-cyan-950/40">
              <canvas
                ref={previewCanvasRef}
                className="w-full h-full object-contain"
              />
              <div className="absolute top-2 left-2 px-2 py-0.5 text-[10px] font-mono text-cyan-300 bg-black/80 rounded border border-cyan-500/40">
                LIVE 60FPS ENCODING
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-300 flex items-center gap-2">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                {progress.statusText}
              </span>
              <span className="font-mono text-cyan-400 tabular-nums font-bold">
                {progress.percentage}%
              </span>
            </div>

            {/* Progress Bar */}
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 via-indigo-500 to-cyan-400 rounded-full transition-all duration-150"
                style={{ width: `${progress.percentage}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
              <span>Elapsed: {progress.elapsedSeconds}s</span>
              <span className="text-emerald-400">{progress.fps} FPS Solid</span>
            </div>

            <button
              onClick={handleCancel}
              className="w-full py-2 text-xs font-semibold text-rose-400 hover:text-rose-300 bg-rose-950/30 hover:bg-rose-950/50 border border-rose-900/60 rounded-xl transition-colors"
            >
              Cancel Render
            </button>
          </div>
        ) : progress.outputBlobUrl ? (
          /* Completed Download & Preview Card */
          <div className="space-y-4 my-4">
            <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-center">
              <CheckCircle2 className="w-6 h-6 text-emerald-400 mx-auto mb-1" />
              <h3 className="text-sm font-bold text-white">Reel Rendered Successfully!</h3>
              <p className="text-xs text-slate-400 mt-0.5 font-mono">
                Locked at 60.0 FPS · {progress.outputSizeMb} MB · 0 dropped frames
              </p>
            </div>

            {/* In-Modal Playback of the rendered output */}
            <div className="relative aspect-[9/16] max-h-60 mx-auto rounded-xl overflow-hidden border border-slate-700 bg-black shadow-lg">
              <video
                src={progress.outputBlobUrl}
                controls
                autoPlay
                playsInline
                loop
                className="w-full h-full object-contain"
              />
            </div>

            <button
              onClick={handleDownload}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 rounded-xl transition-all shadow-lg shadow-cyan-950/60 active:scale-98"
            >
              <Download className="w-4 h-4" />
              Download Crisp 60FPS Video
            </button>

            {/* Instagram Posting Checklist */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 space-y-1">
              <div className="font-semibold text-slate-300 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                Before Uploading to Instagram:
              </div>
              <p>• In Instagram: <strong>Settings &rarr; Account &rarr; Data Usage &rarr; Turn ON "Upload at highest quality"</strong>.</p>
              <p>• Upload over Wi-Fi to keep Instagram from applying cellular compression.</p>
            </div>
          </div>
        ) : (
          /* Initial Ready State */
          <div className="space-y-4">
            <button
              onClick={handleStartExport}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 text-xs font-bold text-white bg-gradient-to-r from-cyan-600 via-indigo-600 to-cyan-600 hover:from-cyan-500 hover:to-indigo-500 rounded-xl transition-all shadow-lg shadow-cyan-950/60 active:scale-98"
            >
              <Sparkles className="w-4 h-4" />
              Render 60 FPS Enhanced Reel Now
            </button>

            <p className="text-center text-[11px] text-slate-500">
              Synchronized 60 FPS hardware renderer guarantees in-sync audio and smooth playback with zero dropped frames.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
