/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Sparkles, Download, ShieldCheck, Smartphone, Sliders } from 'lucide-react';

interface TopBarProps {
  activeTab: 'workspace' | 'presets' | 'permissions' | 'apk';
  setActiveTab: (tab: 'workspace' | 'presets' | 'permissions' | 'apk') => void;
  onOpenExport: () => void;
  isProcessing: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  onOpenExport,
  isProcessing
}) => {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-8 px-5 py-3 border-b border-slate-800 bg-[#0B0F17]/90 backdrop-blur-md">
      {/* Zone 1: Single Brand Wordmark */}
      <div className="flex items-center gap-2.5 shrink-0">
        <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 via-indigo-500 to-rose-500 p-[1.5px]">
          <div className="w-full h-full bg-[#0B0F17] rounded-[7px] flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-cyan-400" />
          </div>
        </div>
        <button
          onClick={() => setActiveTab('workspace')}
          className="text-left font-display text-lg font-bold tracking-tight text-white hover:text-cyan-300 transition-colors whitespace-nowrap shrink-0"
        >
          Topaz<span className="text-cyan-400">Reel</span>
        </button>
      </div>

      {/* Zone 2: 4 Single-Line Navigation Links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
        <button
          onClick={() => setActiveTab('workspace')}
          className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'workspace' ? 'text-cyan-400 font-semibold' : 'hover:text-slate-200'
          }`}
        >
          <Sliders className="w-4 h-4" />
          Studio Workspace
        </button>
        <button
          onClick={() => setActiveTab('presets')}
          className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'presets' ? 'text-cyan-400 font-semibold' : 'hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          Reel Presets
        </button>
        <button
          onClick={() => setActiveTab('permissions')}
          className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'permissions' ? 'text-cyan-400 font-semibold' : 'hover:text-slate-200'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          Device Permissions
        </button>
        <button
          onClick={() => setActiveTab('apk')}
          className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'apk' ? 'text-cyan-400 font-semibold' : 'hover:text-slate-200'
          }`}
        >
          <Smartphone className="w-4 h-4" />
          Direct APK &amp; ZIP
        </button>
      </nav>

      {/* Zone 3: Exactly 1 Primary Action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onOpenExport}
          disabled={isProcessing}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-cyan-600 to-indigo-600 rounded-lg hover:from-cyan-500 hover:to-indigo-500 transition-all shadow-lg shadow-cyan-950/40 active:scale-95 disabled:opacity-50 disabled:pointer-events-none whitespace-nowrap shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          Export 60FPS Reel
        </button>
      </div>
    </header>
  );
};
