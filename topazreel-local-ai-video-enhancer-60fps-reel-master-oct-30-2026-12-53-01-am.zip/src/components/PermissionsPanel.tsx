/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ShieldCheck, HardDrive, Cpu, Camera, Mic, Bell, CheckCircle2, AlertCircle, Sparkles, RefreshCw } from 'lucide-react';
import { PermissionStatusItem } from '../types';
import { checkAllPermissions, requestAllPermissions } from '../utils/permissions';

export const PermissionsPanel: React.FC = () => {
  const [permissions, setPermissions] = useState<PermissionStatusItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [gpuInfo, setGpuInfo] = useState<{ vendor: string; renderer: string; maxTexture: number | string }>({
    vendor: 'Detecting...',
    renderer: 'Detecting...',
    maxTexture: 'Detecting...'
  });
  const [grantSuccessMsg, setGrantSuccessMsg] = useState<string | null>(null);

  const refreshPermissions = async () => {
    setIsLoading(true);
    const items = await checkAllPermissions();
    setPermissions(items);

    // Inspect local GPU WebGL2
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl2');
      if (gl) {
        const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
        setGpuInfo({
          vendor: debugInfo ? gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) : 'Local Hardware',
          renderer: debugInfo ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : 'Hardware Accelerated GPU',
          maxTexture: gl.getParameter(gl.MAX_TEXTURE_SIZE)
        });
      }
    } catch {
      // GPU info fallback
    }
    setIsLoading(false);
  };

  useEffect(() => {
    refreshPermissions();
  }, []);

  const handleGrantAll = async () => {
    setIsLoading(true);
    const result = await requestAllPermissions();
    await refreshPermissions();
    setIsLoading(false);
    setGrantSuccessMsg(`Permissions updated! (${result.grantedCount} enabled)`);
    setTimeout(() => setGrantSuccessMsg(null), 4000);
  };

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'HardDrive': return <HardDrive className="w-5 h-5 text-cyan-400" />;
      case 'Cpu': return <Cpu className="w-5 h-5 text-indigo-400" />;
      case 'Camera': return <Camera className="w-5 h-5 text-rose-400" />;
      case 'Mic': return <Mic className="w-5 h-5 text-emerald-400" />;
      case 'Bell': return <Bell className="w-5 h-5 text-amber-400" />;
      default: return <ShieldCheck className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-8">
      {/* Editorial Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-cyan-400" />
            Device Permissions &amp; Hardware Acceleration
          </h1>
          <p className="mt-1 text-sm text-slate-400 max-w-xl text-balance">
            Allow all device permissions to unlock zero-latency 60 FPS video export, persistent local disk caching, and direct 4K camera capture.
          </p>
        </div>

        {/* 1-Click Allow All Button */}
        <button
          onClick={handleGrantAll}
          disabled={isLoading}
          className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 rounded-xl transition-all shadow-lg shadow-cyan-950/50 active:scale-95 disabled:opacity-50 shrink-0"
        >
          {isLoading ? (
            <RefreshCw className="w-4 h-4 animate-spin" />
          ) : (
            <Sparkles className="w-4 h-4" />
          )}
          Allow All Permissions (1-Click)
        </button>
      </div>

      {grantSuccessMsg && (
        <div className="mb-6 p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-medium flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          {grantSuccessMsg}
        </div>
      )}

      {/* GPU Hardware Diagnostics Card */}
      <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 mb-6">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-semibold text-white">Local Hardware Acceleration Engine</h3>
          </div>
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
            Active · Consumer GPU
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-500 text-[11px] block">GPU Renderer</span>
            <span className="font-mono text-slate-200 truncate block mt-0.5">{gpuInfo.renderer}</span>
          </div>
          <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-500 text-[11px] block">GPU Vendor</span>
            <span className="font-mono text-slate-200 truncate block mt-0.5">{gpuInfo.vendor}</span>
          </div>
          <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-500 text-[11px] block">Max Texture Resolution</span>
            <span className="font-mono text-cyan-300 block mt-0.5">{gpuInfo.maxTexture} x {gpuInfo.maxTexture} (4K+ Ready)</span>
          </div>
        </div>
      </div>

      {/* Permission Items List */}
      <div className="space-y-3 mb-8">
        {permissions.map((perm) => (
          <div
            key={perm.id}
            className="flex items-center justify-between p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition-colors"
          >
            <div className="flex items-center gap-3.5">
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                {getIcon(perm.icon)}
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">{perm.name}</h4>
                <p className="text-xs text-slate-400 max-w-lg mt-0.5">{perm.description}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {perm.status === 'granted' ? (
                <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 bg-emerald-950/50 px-2.5 py-1 rounded-md border border-emerald-900">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Allowed
                </div>
              ) : perm.status === 'denied' ? (
                <div className="flex items-center gap-1.5 text-xs font-semibold text-rose-400 bg-rose-950/50 px-2.5 py-1 rounded-md border border-rose-900">
                  <AlertCircle className="w-3.5 h-3.5" />
                  Blocked
                </div>
              ) : (
                <button
                  onClick={handleGrantAll}
                  className="px-3 py-1 text-xs font-semibold text-cyan-300 bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 rounded-md transition-colors"
                >
                  Enable
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Zero Cloud & Privacy Guarantee */}
      <div className="p-5 rounded-xl bg-slate-950 border border-slate-800/80">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
          100% Client-Side Privacy Architecture
        </h4>
        <p className="text-xs text-slate-400 leading-relaxed">
          Unlike online SaaS tools that upload your videos to remote servers with paywalls and watermarks, TopazReel executes entirely within your browser's WebGL2 sandbox. No frames or audio ever leave your local machine.
        </p>
      </div>
    </div>
  );
};
