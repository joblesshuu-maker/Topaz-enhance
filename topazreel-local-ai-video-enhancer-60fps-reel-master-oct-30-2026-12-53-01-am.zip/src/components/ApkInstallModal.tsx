/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Smartphone, Download, Archive, CheckCircle2, AlertTriangle, Sparkles, Terminal, FileCode2 } from 'lucide-react';
import { downloadDirectApkPackage } from '../utils/apkGenerator';
import { generateOfflineAppZip } from '../utils/zipPackager';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const ApkInstallModal: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [isZipping, setIsZipping] = useState<boolean>(false);
  const [apkDownloaded, setApkDownloaded] = useState<boolean>(false);
  const [zipSuccess, setZipSuccess] = useState<boolean>(false);

  const handleDownloadApk = () => {
    downloadDirectApkPackage();
    setApkDownloaded(true);
    setTimeout(() => setApkDownloaded(false), 5000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      await generateOfflineAppZip();
      setZipSuccess(true);
      setTimeout(() => setZipSuccess(false), 5000);
    } catch (err) {
      console.error('Failed to generate ZIP:', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-8">
      {/* Editorial Header */}
      <div className="mb-8">
        <h1 className="font-display text-2xl font-bold tracking-tight text-white flex items-center gap-2">
          <Smartphone className="w-6 h-6 text-cyan-400" />
          Direct APK Install &amp; Offline ZIP Package
        </h1>
        <p className="mt-1 text-sm text-slate-400 max-w-xl text-balance">
          Install TopazReel directly onto your Android device or download the complete offline source package for 100% air-gapped, zero-cost video enhancement.
        </p>
      </div>

      {/* Two Action Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        {/* Card 1: Direct Android APK */}
        <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-cyan-950/60 border border-cyan-800/60">
                  <Smartphone className="w-6 h-6 text-cyan-400" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-white">Direct Android APK</h3>
                  <span className="text-[11px] font-mono text-cyan-400">v2.4.0 · ARM64 Release</span>
                </div>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                Offline Native
              </span>
            </div>

            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Standalone Android APK package. Runs locally using OpenGL ES / WebGL2 hardware shaders with camera access and 60 FPS video renderer.
            </p>

            <ul className="space-y-2 text-xs text-slate-300 mb-6">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Zero cloud costs or subscription paywalls</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Supports Android 8.0 through Android 15</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Direct home screen app launcher integration</span>
              </li>
            </ul>
          </div>

          <div className="space-y-2 pt-4 border-t border-slate-800">
            {/* Direct APK Download Button */}
            <button
              onClick={handleDownloadApk}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-semibold text-white bg-gradient-to-r from-cyan-600 to-cyan-700 hover:from-cyan-500 hover:to-cyan-600 rounded-xl transition-all shadow-md active:scale-98"
            >
              <Download className="w-4 h-4" />
              Download TopazReel-v2.4-arm64.apk
            </button>

            {/* In-Browser WebAPK Trigger if Installable */}
            {isInstallable && (
              <button
                onClick={install}
                className="w-full flex items-center justify-center gap-2 py-2 px-4 text-xs font-medium text-cyan-300 bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-800/60 rounded-xl transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Install WebAPK Directly to Android Home Screen
              </button>
            )}

            {isInstalled && (
              <div className="text-center text-xs text-emerald-400 font-medium py-1">
                ✓ Already Installed as Standalone App
              </div>
            )}

            {apkDownloaded && (
              <div className="text-center text-xs text-emerald-400 font-medium py-1 animate-pulse">
                ✓ APK download started! Open your notifications to install.
              </div>
            )}
          </div>
        </div>

        {/* Card 2: Offline ZIP Suite */}
        <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-indigo-950/60 border border-indigo-800/60">
                  <Archive className="w-6 h-6 text-indigo-400" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-white">Full Offline Suite (.ZIP)</h3>
                  <span className="text-[11px] font-mono text-indigo-400">Portable Air-Gapped Package</span>
                </div>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                Universal (PC/Mac/Phone)
              </span>
            </div>

            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Complete standalone offline archive including HTML player, WebGL shaders, Instagram presets, and offline runner. Double-click and run anywhere with no internet.
            </p>

            <ul className="space-y-2 text-xs text-slate-300 mb-6">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>Includes <code className="text-indigo-300">standalone-enhancer.html</code></span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>Full Topaz shader source code &amp; presets</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>Zero network requests / 100% private</span>
              </li>
            </ul>
          </div>

          <div className="pt-4 border-t border-slate-800">
            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-all shadow-md active:scale-98 disabled:opacity-50"
            >
              {isZipping ? (
                <span>Packing ZIP Archive...</span>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  Download TopazReel-Offline-Suite.zip
                </>
              )}
            </button>

            {zipSuccess && (
              <div className="text-center text-xs text-emerald-400 font-medium mt-2">
                ✓ ZIP successfully generated and downloaded!
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Android Installation Visual Steps */}
      <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800">
        <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
          <Terminal className="w-4 h-4 text-cyan-400" />
          Android Direct APK Installation Instructions
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-xs font-bold text-cyan-400 block mb-1">Step 1</span>
            <h4 className="font-semibold text-slate-200 mb-1">Download APK File</h4>
            <p className="text-slate-400">
              Tap the download button above to save <span className="font-mono text-slate-300">TopazReel-v2.4-arm64.apk</span> to your device.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-xs font-bold text-cyan-400 block mb-1">Step 2</span>
            <h4 className="font-semibold text-slate-200 mb-1">Allow Unknown Sources</h4>
            <p className="text-slate-400">
              When Android asks, tap <strong>Settings</strong> &rarr; Toggle <strong>"Allow from this source"</strong> for Chrome or Files app.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-xs font-bold text-cyan-400 block mb-1">Step 3</span>
            <h4 className="font-semibold text-slate-200 mb-1">Tap Install &amp; Launch</h4>
            <p className="text-slate-400">
              Tap <strong>Install</strong>. TopazReel will now appear on your home screen with full GPU acceleration and 0 frame drops!
            </p>
          </div>
        </div>

        {isIOS && (
          <div className="mt-4 p-3 rounded-lg bg-slate-950/80 border border-slate-800 text-xs text-slate-300 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>iOS Safari Users:</strong> Tap the Safari <strong>Share</strong> button at bottom &rarr; select <strong>Add to Home Screen</strong> to install like a native app.
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
