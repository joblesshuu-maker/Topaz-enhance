/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Play, Pause, RotateCcw, Volume2, VolumeX, Maximize2, Minimize2,
  Columns, Eye, SplitSquareVertical, Upload, Camera, ZoomIn, ZoomOut,
  ChevronLeft, ChevronRight, Check, Sliders, AlertCircle, FileVideo
} from 'lucide-react';
import { EnhancementSettings, ComparisonMode } from '../types';
import { WebGLEnhancer } from '../engine/webglEnhancer';
import { SAMPLE_CLIPS } from '../utils/sampleVideos';

interface VideoWorkspaceProps {
  settings: EnhancementSettings;
  onUpdateSettings: (newSettings: Partial<EnhancementSettings>) => void;
  comparisonMode: ComparisonMode;
  setComparisonMode: (mode: ComparisonMode) => void;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  videoSrc: string | null;
  setVideoSrc: (src: string) => void;
  videoFileName: string;
  setVideoFileName: (name: string) => void;
  videoFileSize: string;
  setVideoFileSize: (size: string) => void;
  activePresetName: string;
  isControlsCollapsed: boolean;
  onToggleControls: () => void;
}

export const VideoWorkspace: React.FC<VideoWorkspaceProps> = ({
  settings,
  comparisonMode,
  setComparisonMode,
  videoRef,
  canvasRef,
  videoSrc,
  setVideoSrc,
  videoFileName,
  setVideoFileName,
  videoFileSize,
  setVideoFileSize,
  activePresetName,
  isControlsCollapsed,
  onToggleControls
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const enhancerRef = useRef<WebGLEnhancer | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Split curtain position (0.0 to 1.0)
  const [splitPos, setSplitPos] = useState<number>(0.5);
  const [isDraggingSplit, setIsDraggingSplit] = useState<boolean>(false);

  // Playback state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [isLooping, setIsLooping] = useState<boolean>(true);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Drag and drop state
  const [isDraggingFile, setIsDraggingFile] = useState<boolean>(false);
  const [uploadToast, setUploadToast] = useState<string | null>(null);

  // Zoom & Pan state
  const [zoomLevel, setZoomLevel] = useState<number>(1.0);
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Camera recording modal/state
  const [isRecordingCamera, setIsRecordingCamera] = useState<boolean>(false);
  const [cameraCountdown, setCameraCountdown] = useState<number>(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  // Real-time FPS monitoring
  const [measuredFps, setMeasuredFps] = useState<number>(60);
  const frameCountRef = useRef<number>(0);
  const lastFpsTimeRef = useRef<number>(performance.now());

  // Initialize WebGLEnhancer
  useEffect(() => {
    if (canvasRef.current) {
      enhancerRef.current = new WebGLEnhancer(canvasRef.current);
    }
    return () => {
      enhancerRef.current?.destroy();
      enhancerRef.current = null;
    };
  }, [canvasRef]);

  // Main render loop
  const renderFrame = useCallback(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const enhancer = enhancerRef.current;

    if (video && canvas && enhancer && video.readyState >= 2) {
      if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
        canvas.width = video.videoWidth || 1080;
        canvas.height = video.videoHeight || 1920;
      }

      enhancer.render(video, settings, comparisonMode, splitPos);

      // Measure real-time FPS
      frameCountRef.current++;
      const now = performance.now();
      if (now - lastFpsTimeRef.current >= 1000) {
        const fps = Math.round((frameCountRef.current * 1000) / (now - lastFpsTimeRef.current));
        setMeasuredFps(fps);
        frameCountRef.current = 0;
        lastFpsTimeRef.current = now;
      }
    }
  }, [settings, comparisonMode, splitPos, videoRef, canvasRef]);

  // Animation frame loop when playing
  useEffect(() => {
    let animId: number;
    const loop = () => {
      const video = videoRef.current;
      if (video) {
        setCurrentTime(video.currentTime);
      }
      renderFrame();
      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [renderFrame, videoRef]);

  // Reload video source whenever videoSrc updates
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !videoSrc) return;

    video.pause();
    video.src = videoSrc;
    video.load();

    const handleCanPlay = () => {
      setDuration(video.duration || 6);
      video.play().then(() => {
        setIsPlaying(true);
      }).catch(() => {
        setIsPlaying(false);
        renderFrame();
      });
    };

    video.addEventListener('canplay', handleCanPlay, { once: true });
    return () => {
      video.removeEventListener('canplay', handleCanPlay);
    };
  }, [videoSrc, renderFrame, videoRef]);

  // Video metadata loaded
  const handleLoadedMetadata = () => {
    const video = videoRef.current;
    if (video) {
      setDuration(video.duration || 6);
      renderFrame();
    }
  };

  // Play / Pause toggle
  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play().then(() => setIsPlaying(true)).catch(console.error);
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  // Step single frame forward or backward (1/60s)
  const stepFrame = (direction: 1 | -1) => {
    const video = videoRef.current;
    if (!video) return;
    video.pause();
    setIsPlaying(false);
    const frameTime = 1 / 60;
    video.currentTime = Math.max(0, Math.min(video.duration, video.currentTime + direction * frameTime));
  };

  // Scrub timeline
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    const video = videoRef.current;
    if (video) {
      video.currentTime = val;
      setCurrentTime(val);
      renderFrame();
    }
  };

  // Drag split curtain
  const handleSplitMouseDown = (e: React.MouseEvent) => {
    setIsDraggingSplit(true);
    updateSplitFromPointer(e.clientX);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (isDraggingSplit && containerRef.current) {
      updateSplitFromPointer(e.clientX);
    } else if (isPanning && zoomLevel > 1.0) {
      const dx = e.clientX - panStart.x;
      const dy = e.clientY - panStart.y;
      setPanOffset((prev) => ({ x: prev.x + dx, y: prev.y + dy }));
      setPanStart({ x: e.clientX, y: e.clientY });
    }
  };

  const updateSplitFromPointer = (clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pos = Math.max(0.02, Math.min(0.98, (clientX - rect.left) / rect.width));
    setSplitPos(pos);
  };

  const handlePointerUp = () => {
    setIsDraggingSplit(false);
    setIsPanning(false);
  };

  // Core file processing function
  const processUploadedFile = (file: File) => {
    if (!file) return;

    // Check if video file
    if (!file.type.startsWith('video/') && !file.name.match(/\.(mp4|mov|webm|mkv|avi|m4v|3gp|flv)$/i)) {
      alert('Please upload a video file (.mp4, .mov, .webm, .mkv, .avi)');
      return;
    }

    try {
      const url = URL.createObjectURL(file);
      setVideoFileName(file.name);
      setVideoFileSize(`${(file.size / (1024 * 1024)).toFixed(1)} MB`);
      setVideoSrc(url);
      setUploadToast(`Loaded "${file.name}"! Enhancing in 60 FPS...`);
      setTimeout(() => setUploadToast(null), 4000);
    } catch (err) {
      console.error('Error creating video object URL:', err);
      alert('Could not open video file. Please try another MP4 or WebM video.');
    }
  };

  // File input change handler
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processUploadedFile(file);
    }
    // Reset value so user can re-upload or select the same file again
    e.target.value = '';
  };

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processUploadedFile(file);
    }
  };

  // Direct Camera Recording for Instant Reel
  const startCameraRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1080 }, height: { ideal: 1920 }, facingMode: 'user' },
        audio: true
      });

      setIsRecordingCamera(true);
      setCameraCountdown(5);

      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        setVideoFileName('Camera_Reel_Selfie.webm');
        setVideoFileSize(`${(blob.size / (1024 * 1024)).toFixed(1)} MB`);
        setVideoSrc(url);
        stream.getTracks().forEach((t) => t.stop());
        setIsRecordingCamera(false);
      };

      recorder.start();

      let secondsLeft = 5;
      const timer = setInterval(() => {
        secondsLeft--;
        setCameraCountdown(secondsLeft);
        if (secondsLeft <= 0) {
          clearInterval(timer);
          recorder.stop();
        }
      }, 1000);
    } catch (err) {
      console.error('Camera access failed:', err);
      alert('Unable to access camera. Please allow camera permissions in Device Permissions tab.');
      setIsRecordingCamera(false);
    }
  };

  // Toggle true monitor fullscreen
  const toggleMonitorFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen().then(() => setIsFullscreen(true)).catch(console.error);
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(console.error);
    }
  };

  // Load sample clip
  const loadSample = async (sample: typeof SAMPLE_CLIPS[0]) => {
    const tempCanvas = document.createElement('canvas');
    const url = await sample.generateCanvasVideo(tempCanvas, 6);
    setVideoFileName(sample.name);
    setVideoFileSize('60FPS Demo');
    setVideoSrc(url);
    setIsPlaying(true);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 10);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms}`;
  };

  return (
    <div
      ref={containerRef}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className="flex flex-col h-full bg-[#0B0F17] select-none relative"
    >
      {/* Drag & Drop Visual Overlay */}
      {isDraggingFile && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-cyan-950/90 backdrop-blur-md border-4 border-dashed border-cyan-400 p-6 text-center animate-in fade-in duration-100">
          <Upload className="w-16 h-16 text-cyan-300 animate-bounce mb-3" />
          <h2 className="text-xl font-bold text-white">Drop Your Video File Here</h2>
          <p className="text-sm text-cyan-200 mt-1">Supports MP4, MOV, WebM, MKV, AVI · 100% Local GPU Processing</p>
        </div>
      )}

      {/* Top Bar Status & View Mode Controls Strip */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2 border-b border-slate-800/80 bg-slate-950/60 text-xs">
        {/* Left: Active File & Preset Info */}
        <div className="flex items-center gap-2.5 overflow-hidden">
          <div className="flex items-center gap-1.5 font-semibold text-slate-200 truncate">
            <FileVideo className="w-4 h-4 text-cyan-400 shrink-0" />
            <span className="truncate max-w-[200px]" title={videoFileName}>{videoFileName}</span>
            <span className="text-[11px] font-mono text-slate-500">({videoFileSize})</span>
          </div>
          <span className="text-slate-600 hidden sm:inline" aria-hidden="true">·</span>
          <span className="text-emerald-400 font-mono font-medium hidden sm:inline">{measuredFps} FPS Real-time</span>
          <span className="text-slate-600 hidden md:inline" aria-hidden="true">·</span>
          <span className="text-cyan-400 font-mono hidden md:inline">{activePresetName}</span>
        </div>

        {/* Right: Screen Mode Controls */}
        <div className="flex items-center gap-2">
          {/* View Mode Switcher: Enhanced Full Screen vs Split vs 2-Up */}
          <div className="flex items-center gap-1 p-0.5 bg-slate-900 border border-slate-800 rounded-lg">
            <button
              onClick={() => setComparisonMode('enhanced-only')}
              title="Full Screen Enhanced - Sharpening &amp; filters apply to the ENTIRE screen"
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded transition-colors ${
                comparisonMode === 'enhanced-only'
                  ? 'bg-cyan-500 text-slate-950 shadow-sm font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Full Screen Enhanced</span>
            </button>

            <button
              onClick={() => setComparisonMode('split')}
              title="Split Curtain - Compare Before vs After with draggable slider"
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                comparisonMode === 'split'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <SplitSquareVertical className="w-3.5 h-3.5" />
              <span>Split (Half/Half)</span>
            </button>

            <button
              onClick={() => setComparisonMode('side-by-side')}
              title="Side-by-Side Dual View"
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                comparisonMode === 'side-by-side'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Columns className="w-3.5 h-3.5" />
              <span>Side-by-Side</span>
            </button>

            <button
              onClick={() => setComparisonMode('original-only')}
              title="Original Low-Res Only"
              className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                comparisonMode === 'original-only'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>Original</span>
            </button>
          </div>

          {/* Toggle Controls Panel for Full Viewport Width */}
          <button
            onClick={onToggleControls}
            className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-lg border transition-colors ${
              isControlsCollapsed
                ? 'bg-cyan-950 text-cyan-300 border-cyan-700'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
            title={isControlsCollapsed ? 'Show Controls Panel' : 'Hide Controls Panel (Maximize Video)'}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isControlsCollapsed ? 'Show Controls' : 'Full Width'}</span>
          </button>

          {/* Monitor Fullscreen Button */}
          <button
            onClick={toggleMonitorFullscreen}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg transition-colors"
            title={isFullscreen ? 'Exit Fullscreen' : 'Enter Monitor Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Viewport Container */}
      <div
        ref={viewportRef}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        className="relative flex-1 flex items-center justify-center p-3 overflow-hidden bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-900/60 via-[#0B0F17] to-[#0B0F17]"
      >
        {/* Hidden Source Video Element */}
        <video
          ref={videoRef}
          src={videoSrc || undefined}
          crossOrigin={videoSrc && !videoSrc.startsWith('blob:') && !videoSrc.startsWith('data:') && videoSrc.startsWith('http') ? 'anonymous' : undefined}
          playsInline
          muted={isMuted}
          loop={isLooping}
          onLoadedMetadata={handleLoadedMetadata}
          className="hidden"
        />

        {/* Upload Toast Banner */}
        {uploadToast && (
          <div className="absolute top-4 z-40 px-4 py-2 bg-cyan-950 border border-cyan-500 rounded-xl shadow-xl text-xs font-semibold text-cyan-200 flex items-center gap-2 animate-in fade-in">
            <Check className="w-4 h-4 text-cyan-400" />
            {uploadToast}
          </div>
        )}

        {/* Viewport Frame (9:16 vertical Reel aspect) */}
        <div
          className="relative max-h-full aspect-[9/16] rounded-xl overflow-hidden shadow-2xl shadow-black/80 border border-slate-800 bg-black flex items-center justify-center"
          style={{
            cursor: zoomLevel > 1.0 ? (isPanning ? 'grabbing' : 'grab') : 'default'
          }}
          onMouseDown={(e) => {
            if (zoomLevel > 1.0) {
              setIsPanning(true);
              setPanStart({ x: e.clientX, y: e.clientY });
            }
          }}
        >
          {/* WebGL2 Hardware Accelerated Canvas */}
          <canvas
            ref={canvasRef}
            className="w-full h-full object-contain pointer-events-none transition-transform duration-75"
            style={{
              transform: `scale(${zoomLevel}) translate(${panOffset.x / zoomLevel}px, ${panOffset.y / zoomLevel}px)`
            }}
          />

          {/* Interactive Split Curtain Divider & Handle (Only in Split Mode) */}
          {comparisonMode === 'split' && (
            <div
              onMouseDown={handleSplitMouseDown}
              className="absolute top-0 bottom-0 z-20 flex items-center justify-center cursor-ew-resize select-none"
              style={{ left: `${splitPos * 100}%`, transform: 'translateX(-50%)' }}
            >
              {/* Vertical hairline */}
              <div className="w-[2px] h-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]" />

              {/* Draggable diamond badge */}
              <div className="absolute top-1/2 -translate-y-1/2 flex items-center justify-center w-8 h-8 rounded-full bg-slate-900/90 border border-cyan-400 text-cyan-300 shadow-xl backdrop-blur-md active:scale-110 transition-transform">
                <div className="flex items-center gap-0.5">
                  <ChevronLeft className="w-3 h-3 -mr-0.5" />
                  <ChevronRight className="w-3 h-3 -ml-0.5" />
                </div>
              </div>
            </div>
          )}

          {/* Floating Badges */}
          {comparisonMode === 'enhanced-only' && (
            <div className="absolute top-4 right-4 z-10 px-2.5 py-1 text-[11px] font-semibold text-cyan-300 bg-cyan-950/80 rounded-md border border-cyan-500/50 backdrop-blur-sm pointer-events-none flex items-center gap-1.5 shadow-md">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
              Full Screen Enhanced (100% Frame)
            </div>
          )}

          {comparisonMode === 'split' && (
            <>
              <div
                className="absolute top-4 left-4 z-10 px-2 py-1 text-[11px] font-semibold text-slate-300 bg-slate-950/80 rounded border border-slate-700/60 backdrop-blur-sm pointer-events-none"
                style={{ opacity: splitPos > 0.15 ? 1 : 0 }}
              >
                Original (Unsharpened)
              </div>
              <div
                className="absolute top-4 right-4 z-10 px-2 py-1 text-[11px] font-semibold text-cyan-300 bg-cyan-950/80 rounded border border-cyan-500/50 backdrop-blur-sm pointer-events-none"
                style={{ opacity: splitPos < 0.85 ? 1 : 0 }}
              >
                Topaz 60FPS Enhanced
              </div>
            </>
          )}

          {/* Camera recording countdown banner */}
          {isRecordingCamera && (
            <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/70 backdrop-blur-sm text-center p-6">
              <div className="w-16 h-16 rounded-full border-4 border-rose-500 flex items-center justify-center text-3xl font-bold font-mono text-white animate-pulse">
                {cameraCountdown}
              </div>
              <p className="mt-4 text-sm font-semibold text-rose-400">Recording 60FPS Reel Clip...</p>
              <p className="text-xs text-slate-400 mt-1">Look at camera. It will auto-stop and apply Topaz enhancement.</p>
            </div>
          )}
        </div>

        {/* Floating Zoom Controls */}
        <div className="absolute bottom-5 right-5 z-20 flex items-center gap-1 p-1 bg-slate-900/90 border border-slate-800 rounded-lg backdrop-blur-md">
          <button
            onClick={() => {
              const newZoom = Math.max(1.0, zoomLevel - 0.5);
              setZoomLevel(newZoom);
              if (newZoom === 1.0) setPanOffset({ x: 0, y: 0 });
            }}
            disabled={zoomLevel <= 1.0}
            className="p-1.5 text-slate-400 hover:text-white disabled:opacity-30 rounded hover:bg-slate-800"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="px-2 text-xs font-mono font-medium text-slate-300">
            {Math.round(zoomLevel * 100)}%
          </span>
          <button
            onClick={() => setZoomLevel(Math.min(3.0, zoomLevel + 0.5))}
            disabled={zoomLevel >= 3.0}
            className="p-1.5 text-slate-400 hover:text-white disabled:opacity-30 rounded hover:bg-slate-800"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          {zoomLevel > 1.0 && (
            <button
              onClick={() => {
                setZoomLevel(1.0);
                setPanOffset({ x: 0, y: 0 });
              }}
              className="px-2 py-0.5 text-[10px] font-mono text-cyan-400 hover:bg-cyan-950/40 rounded"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Scrub Bar & Transport Controls */}
      <div className="px-5 py-3 border-t border-slate-800 bg-[#0B0F17]/95">
        {/* Progress Slider */}
        <div className="flex items-center gap-3 mb-2">
          <span className="font-mono text-xs text-slate-400 w-16 text-right tabular-nums">
            {formatTime(currentTime)}
          </span>
          <input
            type="range"
            min={0}
            max={duration || 6}
            step={0.016}
            value={currentTime}
            onChange={handleSeek}
            className="flex-1 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
          />
          <span className="font-mono text-xs text-slate-500 w-16 tabular-nums">
            {formatTime(duration)}
          </span>
        </div>

        {/* Buttons Row */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Left Transport */}
          <div className="flex items-center gap-2">
            <button
              onClick={togglePlay}
              className="flex items-center justify-center w-8 h-8 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white transition-colors shadow-sm"
              title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
            </button>

            <button
              onClick={() => stepFrame(-1)}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              title="Step -1 Frame"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => stepFrame(1)}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              title="Step +1 Frame"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                const video = videoRef.current;
                if (video) {
                  video.currentTime = 0;
                  setCurrentTime(0);
                }
              }}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              title="Restart Video"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            <button
              onClick={() => setIsLooping(!isLooping)}
              className={`px-2 py-1 text-xs font-mono rounded transition-colors ${
                isLooping ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-800/60' : 'text-slate-500 hover:text-slate-300'
              }`}
              title="Toggle Loop Playback"
            >
              Loop
            </button>
          </div>

          {/* Quick Input Options (Upload & Camera & Samples) */}
          <div className="flex items-center gap-2">
            {/* The working file input with comprehensive video format acceptance */}
            <input
              type="file"
              ref={fileInputRef}
              accept="video/mp4,video/webm,video/quicktime,video/x-matroska,video/*,.mp4,.mov,.webm,.mkv,.avi"
              onChange={handleFileInputChange}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 border border-cyan-400/30 rounded-lg shadow-sm transition-all active:scale-95"
            >
              <Upload className="w-3.5 h-3.5" />
              Upload Video
            </button>

            <button
              onClick={startCameraRecording}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-900 border border-slate-700 hover:border-rose-500 rounded-lg transition-colors"
            >
              <Camera className="w-3.5 h-3.5 text-rose-400" />
              Record Clip
            </button>

            {/* Quick Sample Selector */}
            <div className="hidden sm:flex items-center gap-1 ml-2 border-l border-slate-800 pl-3">
              <span className="text-[11px] text-slate-500 mr-1">Demo Clips:</span>
              {SAMPLE_CLIPS.map((sample) => (
                <button
                  key={sample.id}
                  onClick={() => loadSample(sample)}
                  className="px-2.5 py-1 text-[11px] font-medium text-slate-300 bg-slate-800/80 hover:bg-slate-700 hover:text-white rounded transition-colors whitespace-nowrap"
                >
                  {sample.name.split('/')[0].trim()}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
