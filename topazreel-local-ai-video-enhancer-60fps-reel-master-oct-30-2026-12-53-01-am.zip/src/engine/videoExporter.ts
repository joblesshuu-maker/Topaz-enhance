/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { EnhancementSettings, ReelPreset, ExportProgress } from '../types';
import { WebGLEnhancer } from './webglEnhancer';

export class VideoExporter {
  private isCancelled = false;

  public cancel() {
    this.isCancelled = true;
  }

  public async exportEnhancedVideo(
    sourceVideo: HTMLVideoElement,
    preset: ReelPreset,
    settings: EnhancementSettings,
    onProgress: (progress: ExportProgress) => void,
    previewCanvas?: HTMLCanvasElement | null
  ): Promise<string> {
    this.isCancelled = false;

    const targetWidth = preset.targetResolution.width;
    const targetHeight = preset.targetResolution.height;
    const targetFps = settings.targetFps || 60;

    // Accurately determine video duration
    let duration = 6;
    if (sourceVideo.duration && isFinite(sourceVideo.duration) && sourceVideo.duration > 0) {
      duration = sourceVideo.duration;
    }

    // Save original loop state and disable it so playback stops at the end
    const originalLoop = sourceVideo.loop;
    sourceVideo.loop = false;

    // Create export canvas at preset resolution
    const exportCanvas = previewCanvas || document.createElement('canvas');
    exportCanvas.width = targetWidth;
    exportCanvas.height = targetHeight;

    const enhancer = new WebGLEnhancer(exportCanvas);

    // Audio stream extraction setup
    let audioTrack: MediaStreamTrack | null = null;
    try {
      const vStream = (sourceVideo as unknown as { captureStream?: () => MediaStream; mozCaptureStream?: () => MediaStream }).captureStream?.()
        || (sourceVideo as unknown as { mozCaptureStream?: () => MediaStream }).mozCaptureStream?.();
      if (vStream && vStream.getAudioTracks().length > 0) {
        audioTrack = vStream.getAudioTracks()[0];
      }
    } catch {
      // Audio capture fallback
    }

    // Capture stream from export canvas at exact locked 60 FPS
    const canvasStream = exportCanvas.captureStream(targetFps);

    if (audioTrack) {
      canvasStream.addTrack(audioTrack);
    }

    // Pick optimal supported codec and container
    const mimeTypes = [
      'video/mp4;codecs=avc1.640028,mp4a.40.2',
      'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
      'video/mp4',
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm;codecs=h264',
      'video/webm'
    ];

    let chosenMime = 'video/webm';
    for (const mime of mimeTypes) {
      if (MediaRecorder.isTypeSupported(mime)) {
        chosenMime = mime;
        break;
      }
    }

    const bitrate = Math.min(35000000, Math.round(preset.bitrateMbps * 1000 * 1000));
    const mediaRecorder = new MediaRecorder(canvasStream, {
      mimeType: chosenMime,
      videoBitsPerSecond: bitrate
    });

    const recordedChunks: Blob[] = [];
    mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        recordedChunks.push(e.data);
      }
    };

    // Prepare video for playback from start
    sourceVideo.pause();
    sourceVideo.currentTime = 0;

    // Await seek to frame 0 with guaranteed timeout
    await new Promise<void>((resolve) => {
      let resolved = false;
      const onSeeked = () => {
        if (!resolved) {
          resolved = true;
          sourceVideo.removeEventListener('seeked', onSeeked);
          resolve();
        }
      };
      sourceVideo.addEventListener('seeked', onSeeked);
      setTimeout(onSeeked, 200);
    });

    // Initial render of frame 0
    enhancer.render(sourceVideo, settings, 'enhanced-only');

    const totalFrames = Math.max(1, Math.round(duration * targetFps));
    const startTime = performance.now();
    let renderedFrames = 0;

    return new Promise<string>((resolve, reject) => {
      let animationFrameId: number;
      let intervalId: number;
      let isFinished = false;

      // Register onstop event BEFORE starting recorder to guarantee execution
      mediaRecorder.onstop = () => {
        sourceVideo.loop = originalLoop;
        enhancer.destroy();

        const isMp4 = chosenMime.includes('mp4');
        const finalBlob = new Blob(recordedChunks, { type: isMp4 ? 'video/mp4' : 'video/webm' });
        const outputUrl = URL.createObjectURL(finalBlob);
        const sizeMb = Number((finalBlob.size / (1024 * 1024)).toFixed(2));

        onProgress({
          isExporting: false,
          currentFrame: totalFrames,
          totalFrames,
          percentage: 100,
          fps: targetFps,
          elapsedSeconds: Math.round((performance.now() - startTime) / 1000),
          statusText: `Complete · ${targetFps} FPS Locked (${sizeMb} MB)`,
          outputBlobUrl: outputUrl,
          outputSizeMb: sizeMb
        });

        resolve(outputUrl);
      };

      mediaRecorder.onerror = (e) => {
        sourceVideo.loop = originalLoop;
        enhancer.destroy();
        reject(e);
      };

      const finishExport = () => {
        if (isFinished) return;
        isFinished = true;

        cancelAnimationFrame(animationFrameId);
        clearInterval(intervalId);

        sourceVideo.pause();

        onProgress({
          isExporting: true,
          currentFrame: totalFrames,
          totalFrames,
          percentage: 100,
          fps: targetFps,
          elapsedSeconds: Math.round((performance.now() - startTime) / 1000),
          statusText: 'Finalizing 60 FPS Video File (100%)...',
          outputBlobUrl: null,
          outputSizeMb: 0
        });

        if (mediaRecorder.state !== 'inactive') {
          mediaRecorder.stop();
        }
      };

      const renderLoop = () => {
        if (isFinished) return;

        if (this.isCancelled) {
          isFinished = true;
          cancelAnimationFrame(animationFrameId);
          clearInterval(intervalId);
          sourceVideo.pause();
          sourceVideo.loop = originalLoop;
          mediaRecorder.stop();
          enhancer.destroy();
          reject(new Error('Export cancelled by user'));
          return;
        }

        // Render current video frame through WebGL2 enhancement shaders
        enhancer.render(sourceVideo, settings, 'enhanced-only');
        renderedFrames++;

        const currentPos = sourceVideo.currentTime;
        const progressFrac = Math.min(1.0, currentPos / duration);
        const percentage = Math.min(99, Math.round(progressFrac * 100));
        const elapsed = (performance.now() - startTime) / 1000;
        const currentFps = elapsed > 0 ? Math.round(renderedFrames / elapsed) : targetFps;

        onProgress({
          isExporting: true,
          currentFrame: Math.min(totalFrames, Math.round(currentPos * targetFps)),
          totalFrames,
          percentage: Math.max(1, percentage),
          fps: currentFps || targetFps,
          elapsedSeconds: Math.round(elapsed),
          statusText: `Rendering 60 FPS Reel · ${percentage}% (${currentPos.toFixed(1)}s / ${duration.toFixed(1)}s)`,
          outputBlobUrl: null,
          outputSizeMb: 0
        });

        // Exact completion condition
        const elapsedSec = (performance.now() - startTime) / 1000;
        if (sourceVideo.ended || currentPos >= duration - 0.08 || elapsedSec >= duration + 0.5) {
          finishExport();
          return;
        }

        animationFrameId = requestAnimationFrame(renderLoop);
      };

      // Start recording chunks
      mediaRecorder.start(100);

      // Play video to record real-time synchronized frames
      sourceVideo.play().then(() => {
        animationFrameId = requestAnimationFrame(renderLoop);
      }).catch((err) => {
        console.warn('Playback error during export:', err);
        // Fallback: still run loop even if browser autoplay restrictions engage
        animationFrameId = requestAnimationFrame(renderLoop);
      });

      // Safety timeout watcher in case requestAnimationFrame throttles in background tab
      intervalId = window.setInterval(() => {
        const elapsedSec = (performance.now() - startTime) / 1000;
        if (elapsedSec >= duration + 1.0) {
          finishExport();
        }
      }, 500);
    });
  }
}
