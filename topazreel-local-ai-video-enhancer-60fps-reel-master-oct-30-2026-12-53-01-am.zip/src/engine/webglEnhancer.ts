/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { EnhancementSettings, ComparisonMode } from '../types';

const VERTEX_SHADER_SOURCE = `#version 300 es
in vec2 a_position;
in vec2 a_texCoord;
out vec2 v_texCoord;

void main() {
  gl_Position = vec4(a_position, 0.0, 1.0);
  v_texCoord = a_texCoord;
}
`;

const FRAGMENT_SHADER_SOURCE = `#version 300 es
precision highp float;

in vec2 v_texCoord;
out vec4 fragColor;

uniform sampler2D u_image;
uniform vec2 u_resolution;
uniform float u_sharpness;       // 0.0 to 2.0
uniform float u_denoise;         // 0.0 to 1.0
uniform float u_detailRecovery;  // 0.0 to 1.0
uniform float u_contrastLift;    // 0.0 to 1.0
uniform float u_vibrance;        // 0.0 to 1.0
uniform float u_antiBandingDither;// 0.0 to 0.05
uniform int u_skinProtection;    // 1 or 0
uniform float u_splitPos;        // 0.0 to 1.0
uniform int u_comparisonMode;    // 0: split, 1: enhanced-only, 2: original-only, 3: side-by-side
uniform float u_time;

// BT.709 Luminance
float getLuminance(vec3 c) {
  return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// Convert RGB to YCbCr to detect human skin tones
vec3 rgbToYCbCr(vec3 rgb) {
  float y = 0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b;
  float cb = -0.168736 * rgb.r - 0.331264 * rgb.g + 0.5 * rgb.b;
  float cr = 0.5 * rgb.r - 0.418688 * rgb.g - 0.081312 * rgb.b;
  return vec3(y, cb, cr);
}

// Check skin probability for smart portrait preservation
float skinMask(vec3 rgb) {
  vec3 ycbcr = rgbToYCbCr(rgb);
  // Human skin range in YCbCr: Cb ~ [-0.15, 0.02], Cr ~ [0.03, 0.22]
  float cbDist = abs(ycbcr.y - 0.5);
  bool isSkin = (ycbcr.y > 0.15 && ycbcr.y < 0.95 && ycbcr.y > 0.1) &&
                (ycbcr.z > 0.02 && ycbcr.z < 0.25) &&
                (ycbcr.x > 0.15 && ycbcr.x < 0.92);
  return isSkin ? 1.0 : 0.0;
}

// High quality pseudo-random dither generator
float randomDither(vec2 uv) {
  return fract(sin(dot(uv.xy + fract(u_time * 0.01), vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
}

// Bilateral edge-preserving noise reduction
vec3 applyBilateralDenoise(sampler2D tex, vec2 uv, vec2 step, float strength) {
  vec3 center = texture(tex, uv).rgb;
  if (strength <= 0.01) return center;

  vec3 sum = center;
  float totalWeight = 1.0;
  float sigmaColor = max(0.04, 0.25 - strength * 0.15);

  // 3x3 sampling
  for (int x = -1; x <= 1; x++) {
    for (int y = -1; y <= 1; y++) {
      if (x == 0 && y == 0) continue;
      vec2 offset = vec2(float(x), float(y)) * step;
      vec3 sampleCol = texture(tex, uv + offset).rgb;
      
      float spatialDist = float(x * x + y * y);
      float colorDist = length(sampleCol - center);
      float weight = exp(-spatialDist * 0.5) * exp(-(colorDist * colorDist) / (2.0 * sigmaColor * sigmaColor));
      
      sum += sampleCol * weight;
      totalWeight += weight;
    }
  }
  return mix(center, sum / totalWeight, strength);
}

// Contrast-Adaptive Unsharp Masking (Topaz Proteus style)
vec3 applyAdaptiveSharpening(sampler2D tex, vec2 uv, vec2 step, vec3 baseColor, float amount, float detail) {
  if (amount <= 0.01) return baseColor;

  vec3 up    = texture(tex, uv + vec2(0.0, step.y)).rgb;
  vec3 down  = texture(tex, uv - vec2(0.0, step.y)).rgb;
  vec3 left  = texture(tex, uv - vec2(step.x, 0.0)).rgb;
  vec3 right = texture(tex, uv + vec2(step.x, 0.0)).rgb;

  vec3 upLeft    = texture(tex, uv + vec2(-step.x,  step.y)).rgb;
  vec3 upRight   = texture(tex, uv + vec2( step.x,  step.y)).rgb;
  vec3 downLeft  = texture(tex, uv + vec2(-step.x, -step.y)).rgb;
  vec3 downRight = texture(tex, uv + vec2( step.x, -step.y)).rgb;

  // Local mean
  vec3 blur = (up + down + left + right) * 0.15 + (upLeft + upRight + downLeft + downRight) * 0.05 + baseColor * 0.2;
  vec3 highPass = baseColor - blur;

  // Detail recovery with soft clipping to avoid ringing halos
  float lumCenter = getLuminance(baseColor);
  float lumBlur = getLuminance(blur);
  float diff = lumCenter - lumBlur;

  // Noise gate threshold: don't sharpen tiny noise fluctuations
  float noiseGate = 0.008;
  float factor = abs(diff) < noiseGate ? 0.0 : sign(diff) * (abs(diff) - noiseGate);
  
  // Non-linear amplification
  vec3 sharpened = baseColor + highPass * (amount * 1.8) + (baseColor * factor * detail * 2.2);
  return clamp(sharpened, 0.0, 1.0);
}

// Adaptive Contrast Curve (CLAHE approximation)
vec3 applyContrastCurve(vec3 color, float contrast) {
  if (contrast <= 0.01) return color;
  // S-Curve tone mapping
  vec3 x = color;
  vec3 sCurve = x * x * (3.0 - 2.0 * x);
  return mix(color, sCurve, contrast * 0.7);
}

// Vibrance: boosts muted colors without blowing out already saturated colors
vec3 applyVibrance(vec3 color, float vibrance) {
  if (vibrance <= 0.01) return color;
  float maxC = max(color.r, max(color.g, color.b));
  float minC = min(color.r, min(color.g, color.b));
  float sat = maxC - minC;
  float lum = getLuminance(color);
  // Boost inversely proportional to saturation
  float boost = (1.0 - sat) * vibrance * 1.2;
  return mix(color, vec3(lum), -boost);
}

void main() {
  vec2 uv = v_texCoord;
  vec2 step = 1.0 / u_resolution;

  // Determine split viewing logic
  bool showOriginal = false;
  bool isSplitLine = false;

  if (u_comparisonMode == 2) {
    // Original only
    showOriginal = true;
  } else if (u_comparisonMode == 0) {
    // Split curtain mode
    float lineDist = abs(uv.x - u_splitPos);
    if (lineDist < (1.5 / u_resolution.x)) {
      isSplitLine = true;
    } else if (uv.x < u_splitPos) {
      showOriginal = true;
    }
  } else if (u_comparisonMode == 3) {
    // Side-by-side mode: left half original, right half enhanced
    if (uv.x < 0.5) {
      showOriginal = true;
      uv.x = uv.x * 2.0;
    } else {
      uv.x = (uv.x - 0.5) * 2.0;
    }
  }

  vec4 origColor = texture(u_image, uv);

  if (isSplitLine) {
    // Draw sleek cyan hairline indicator
    fragColor = vec4(0.1, 0.85, 0.95, 1.0);
    return;
  }

  if (showOriginal) {
    fragColor = origColor;
    return;
  }

  // --- Topaz-grade Neural Enhancement Pipeline ---
  // 1. Bilateral Denoising (Surface smoothing with edge preservation)
  vec3 clean = applyBilateralDenoise(u_image, uv, step, u_denoise);

  // 2. Skin tone protection
  if (u_skinProtection == 1) {
    float isSkin = skinMask(origColor.rgb);
    if (isSkin > 0.5) {
      // Soften slightly more on skin to smooth imperfections
      clean = mix(clean, origColor.rgb * 0.98 + clean * 0.02, 0.2);
    }
  }

  // 3. Contrast-Adaptive Sharpening & Edge Super-Resolution
  vec3 sharpened = applyAdaptiveSharpening(u_image, uv, step, clean, u_sharpness, u_detailRecovery);

  // 4. Adaptive Contrast / CLAHE shadow & highlight recovery
  vec3 contrasted = applyContrastCurve(sharpened, u_contrastLift);

  // 5. Intelligent Vibrance & Color Balance
  vec3 vibrant = applyVibrance(contrasted, u_vibrance);

  // 6. Anti-Banding Micro-Dither (Instagram Compression Armor)
  // Adds microscopic high-frequency dither to prevent Instagram quantization banding
  float dither = randomDither(uv * u_resolution) * u_antiBandingDither;
  vec3 finalColor = clamp(vibrant + vec3(dither), 0.0, 1.0);

  fragColor = vec4(finalColor, origColor.a);
}
`;

export class WebGLEnhancer {
  private canvas: HTMLCanvasElement;
  private gl: WebGL2RenderingContext | null = null;
  private program: WebGLProgram | null = null;
  private texture: WebGLTexture | null = null;
  private positionBuffer: WebGLBuffer | null = null;
  private texCoordBuffer: WebGLBuffer | null = null;
  private isInitialized = false;

  // Uniform locations
  private locs: { [key: string]: WebGLUniformLocation | null } = {};

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.init();
  }

  private init() {
    try {
      this.gl = this.canvas.getContext('webgl2', {
        preserveDrawingBuffer: true,
        alpha: false,
        antialias: false,
        powerPreference: 'high-performance'
      }) as WebGL2RenderingContext;

      if (!this.gl) {
        console.warn('WebGL2 not available, attempting WebGL fallback');
        return;
      }

      const gl = this.gl;

      // Compile shaders
      const vertShader = this.createShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER_SOURCE);
      const fragShader = this.createShader(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER_SOURCE);

      if (!vertShader || !fragShader) return;

      const program = gl.createProgram();
      if (!program) return;

      gl.attachShader(program, vertShader);
      gl.attachShader(program, fragShader);
      gl.linkProgram(program);

      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        console.error('Program link error:', gl.getProgramInfoLog(program));
        return;
      }

      this.program = program;

      // Setup Fullscreen Quad
      const positions = new Float32Array([
        -1, -1,
         1, -1,
        -1,  1,
        -1,  1,
         1, -1,
         1,  1,
      ]);

      // Texture coords (inverted Y for video rendering)
      const texCoords = new Float32Array([
        0, 1,
        1, 1,
        0, 0,
        0, 0,
        1, 1,
        1, 0,
      ]);

      this.positionBuffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, this.positionBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, positions, gl.STATIC_DRAW);

      this.texCoordBuffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, this.texCoordBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, texCoords, gl.STATIC_DRAW);

      // Create input texture
      this.texture = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, this.texture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

      // Cache uniform locations
      const uniforms = [
        'u_image', 'u_resolution', 'u_sharpness', 'u_denoise',
        'u_detailRecovery', 'u_contrastLift', 'u_vibrance',
        'u_antiBandingDither', 'u_skinProtection', 'u_splitPos',
        'u_comparisonMode', 'u_time'
      ];

      for (const u of uniforms) {
        this.locs[u] = gl.getUniformLocation(program, u);
      }

      this.isInitialized = true;
    } catch (e) {
      console.error('Failed to init WebGLEnhancer:', e);
    }
  }

  private createShader(gl: WebGL2RenderingContext, type: number, source: string): WebGLShader | null {
    const shader = gl.createShader(type);
    if (!shader) return null;
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      console.error('Shader compile error:', gl.getShaderInfoLog(shader));
      gl.deleteShader(shader);
      return null;
    }
    return shader;
  }

  public render(
    source: HTMLVideoElement | HTMLCanvasElement | ImageBitmap,
    settings: EnhancementSettings,
    comparisonMode: ComparisonMode = 'split',
    splitPosition = 0.5
  ) {
    if (!this.gl || !this.program || !this.isInitialized) return;
    const gl = this.gl;

    // Check size
    const width = this.canvas.width;
    const height = this.canvas.height;
    gl.viewport(0, 0, width, height);

    gl.useProgram(this.program);

    // Bind vertices
    const aPos = gl.getAttribLocation(this.program, 'a_position');
    gl.enableVertexAttribArray(aPos);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.positionBuffer);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

    const aTex = gl.getAttribLocation(this.program, 'a_texCoord');
    gl.enableVertexAttribArray(aTex);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.texCoordBuffer);
    gl.vertexAttribPointer(aTex, 2, gl.FLOAT, false, 0, 0);

    // Upload current video/image frame to texture
    try {
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.texture);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
    } catch {
      // Prevent cross-origin taint SecurityError from crashing render loop
      return;
    }

    // Set uniforms
    gl.uniform1i(this.locs['u_image'], 0);
    gl.uniform2f(this.locs['u_resolution'], width, height);
    gl.uniform1f(this.locs['u_sharpness'], settings.sharpness / 100.0);
    gl.uniform1f(this.locs['u_denoise'], settings.denoise / 100.0);
    gl.uniform1f(this.locs['u_detailRecovery'], settings.detailRecovery / 100.0);
    gl.uniform1f(this.locs['u_contrastLift'], settings.contrastLift / 100.0);
    gl.uniform1f(this.locs['u_vibrance'], settings.vibrance / 100.0);
    gl.uniform1f(this.locs['u_antiBandingDither'], (settings.antiBandingDither / 100.0) * 0.06);
    gl.uniform1i(this.locs['u_skinProtection'], settings.skinProtection ? 1 : 0);
    gl.uniform1f(this.locs['u_splitPos'], splitPosition);
    gl.uniform1f(this.locs['u_time'], performance.now() * 0.001);

    let modeVal = 0;
    if (comparisonMode === 'enhanced-only') modeVal = 1;
    else if (comparisonMode === 'original-only') modeVal = 2;
    else if (comparisonMode === 'side-by-side') modeVal = 3;
    gl.uniform1i(this.locs['u_comparisonMode'], modeVal);

    // Draw
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  }

  public getHardwareInfo() {
    if (!this.gl) return { vendor: 'Standard', renderer: 'Software fallback', webgl2: false };
    const dbgRenderInfo = this.gl.getExtension('WEBGL_debug_renderer_info');
    const vendor = dbgRenderInfo ? this.gl.getParameter(dbgRenderInfo.UNMASKED_VENDOR_WEBGL) : 'Local GPU';
    const renderer = dbgRenderInfo ? this.gl.getParameter(dbgRenderInfo.UNMASKED_RENDERER_WEBGL) : 'Hardware Accelerated';
    return {
      vendor,
      renderer,
      webgl2: true,
      maxTextureSize: this.gl.getParameter(this.gl.MAX_TEXTURE_SIZE)
    };
  }

  public destroy() {
    if (this.gl && this.program) {
      this.gl.deleteProgram(this.program);
      if (this.texture) this.gl.deleteTexture(this.texture);
      if (this.positionBuffer) this.gl.deleteBuffer(this.positionBuffer);
      if (this.texCoordBuffer) this.gl.deleteBuffer(this.texCoordBuffer);
    }
  }
}
