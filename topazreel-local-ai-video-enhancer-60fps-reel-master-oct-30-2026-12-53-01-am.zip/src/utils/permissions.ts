/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PermissionStatusItem } from '../types';

export async function checkAllPermissions(): Promise<PermissionStatusItem[]> {
  const items: PermissionStatusItem[] = [];

  // 1. Storage Persistence
  try {
    if (navigator.storage && navigator.storage.persisted) {
      const isPersisted = await navigator.storage.persisted();
      items.push({
        id: 'storage',
        name: 'Persistent Local Storage',
        description: 'Enables high-capacity local disk cache for 4K video frames without browser eviction.',
        status: isPersisted ? 'granted' : 'prompt',
        icon: 'HardDrive'
      });
    } else {
      items.push({
        id: 'storage',
        name: 'Persistent Local Storage',
        description: 'Standard browser sandbox storage.',
        status: 'granted',
        icon: 'HardDrive'
      });
    }
  } catch {
    items.push({ id: 'storage', name: 'Persistent Storage', description: 'Local storage', status: 'granted', icon: 'HardDrive' });
  }

  // 2. GPU Hardware Acceleration
  try {
    const testCanvas = document.createElement('canvas');
    const gl = testCanvas.getContext('webgl2');
    if (gl) {
      items.push({
        id: 'gpu',
        name: 'WebGL2 GPU Acceleration',
        description: 'Direct GPU shader pipeline active for real-time 60 FPS neural filtering.',
        status: 'granted',
        icon: 'Cpu'
      });
    } else {
      items.push({
        id: 'gpu',
        name: 'WebGL2 GPU Acceleration',
        description: 'WebGL2 hardware acceleration unsupported.',
        status: 'unsupported',
        icon: 'Cpu'
      });
    }
  } catch {
    items.push({ id: 'gpu', name: 'GPU Acceleration', description: 'Checking GPU', status: 'prompt', icon: 'Cpu' });
  }

  // 3. Camera (for direct Reel recording)
  try {
    if (navigator.permissions && navigator.permissions.query) {
      const camStatus = await navigator.permissions.query({ name: 'camera' as PermissionName });
      items.push({
        id: 'camera',
        name: 'Camera (Selfie & 4K Lens)',
        description: 'Allows recording video clips directly in the studio with instant enhancement.',
        status: camStatus.state as 'granted' | 'denied' | 'prompt',
        icon: 'Camera'
      });
    } else {
      items.push({
        id: 'camera',
        name: 'Camera (Selfie & 4K Lens)',
        description: 'Record clips directly to enhance.',
        status: 'prompt',
        icon: 'Camera'
      });
    }
  } catch {
    items.push({ id: 'camera', name: 'Camera', description: 'Direct capture', status: 'prompt', icon: 'Camera' });
  }

  // 4. Microphone (Audio pass-through)
  try {
    if (navigator.permissions && navigator.permissions.query) {
      const micStatus = await navigator.permissions.query({ name: 'microphone' as PermissionName });
      items.push({
        id: 'microphone',
        name: 'Microphone & Audio Pass-through',
        description: 'Preserves 48kHz stereo AAC audio tracks during export.',
        status: micStatus.state as 'granted' | 'denied' | 'prompt',
        icon: 'Mic'
      });
    } else {
      items.push({
        id: 'microphone',
        name: 'Microphone & Audio',
        description: 'Audio pass-through',
        status: 'prompt',
        icon: 'Mic'
      });
    }
  } catch {
    items.push({ id: 'microphone', name: 'Microphone', description: 'Audio preserve', status: 'prompt', icon: 'Mic' });
  }

  // 5. System Notifications
  try {
    if ('Notification' in window) {
      const state = Notification.permission === 'granted' ? 'granted' : Notification.permission === 'denied' ? 'denied' : 'prompt';
      items.push({
        id: 'notifications',
        name: 'Render Completion Alerts',
        description: 'Notifies you immediately when long 4K/60FPS video render completes.',
        status: state,
        icon: 'Bell'
      });
    } else {
      items.push({ id: 'notifications', name: 'Notifications', description: 'Background alerts', status: 'unsupported', icon: 'Bell' });
    }
  } catch {
    items.push({ id: 'notifications', name: 'Notifications', description: 'Background alerts', status: 'prompt', icon: 'Bell' });
  }

  return items;
}

export async function requestAllPermissions(): Promise<{ success: boolean; grantedCount: number }> {
  let count = 0;

  // 1. Storage persistence
  try {
    if (navigator.storage && navigator.storage.persist) {
      const persisted = await navigator.storage.persist();
      if (persisted) count++;
    }
  } catch (e) {
    console.log('Storage persist error:', e);
  }

  // 2. Camera + Microphone
  try {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      count += 2;
      // Stop tracks immediately after granting
      stream.getTracks().forEach((track) => track.stop());
    }
  } catch (e) {
    console.log('MediaDevices grant error:', e);
  }

  // 3. Notifications
  try {
    if ('Notification' in window && Notification.permission !== 'granted') {
      const res = await Notification.requestPermission();
      if (res === 'granted') count++;
    } else if (Notification.permission === 'granted') {
      count++;
    }
  } catch (e) {
    console.log('Notification permission error:', e);
  }

  return { success: true, grantedCount: count };
}
