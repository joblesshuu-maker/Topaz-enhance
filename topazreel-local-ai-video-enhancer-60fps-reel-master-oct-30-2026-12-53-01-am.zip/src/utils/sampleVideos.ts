/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SampleClip {
  id: string;
  name: string;
  category: string;
  description: string;
  posterUrl: string;
  aspect: string;
  generateCanvasVideo: (canvas: HTMLCanvasElement, durationSeconds: number) => Promise<string>;
}

async function loadSafeBitmap(url: string): Promise<ImageBitmap | null> {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const blob = await res.blob();
    return await createImageBitmap(blob);
  } catch {
    return null;
  }
}

export const SAMPLE_CLIPS: SampleClip[] = [
  {
    id: 'sample-portrait-reel',
    name: 'Portrait / Fashion Reel',
    category: 'Face & Hair Detail',
    description: 'Natural daylight portrait testing Topaz skin smoothing and crisp hair recovery.',
    posterUrl: '/src/assets/images/sample_portrait_reel_1793300310650.jpg',
    aspect: '9:16 (1080x1920)',
    generateCanvasVideo: async (canvas: HTMLCanvasElement, durationSeconds = 5) => {
      canvas.width = 720;
      canvas.height = 1280;
      const ctx = canvas.getContext('2d')!;

      const bitmap = await loadSafeBitmap('/src/assets/images/sample_portrait_reel_1793300310650.jpg');

      const stream = canvas.captureStream(60);
      const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.start();

      const startTime = performance.now();
      const totalMs = durationSeconds * 1000;

      return new Promise<string>((resolve) => {
        const drawFrame = () => {
          const now = performance.now();
          const progress = (now - startTime) / totalMs;

          if (progress >= 1.0) {
            recorder.stop();
            recorder.onstop = () => {
              const blob = new Blob(chunks, { type: 'video/webm' });
              resolve(URL.createObjectURL(blob));
            };
            return;
          }

          if (bitmap) {
            // Subtle cinematic Ken Burns zoom and float
            const zoom = 1.0 + Math.sin(progress * Math.PI) * 0.08;
            const panY = Math.sin(progress * Math.PI * 2) * 15;

            ctx.save();
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.scale(zoom, zoom);
            ctx.drawImage(bitmap, -canvas.width / 2, -canvas.height / 2 + panY, canvas.width, canvas.height);
            ctx.restore();
          } else {
            // Procedural fallback with sharp gradient textures
            const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
            grad.addColorStop(0, '#0f172a');
            grad.addColorStop(0.5, '#1e293b');
            grad.addColorStop(1, '#0284c7');
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
          }

          // Subtle natural bokeh light particles
          ctx.fillStyle = 'rgba(255, 230, 180, 0.15)';
          for (let i = 0; i < 8; i++) {
            const px = (Math.sin(progress * 4 + i) * 0.5 + 0.5) * canvas.width;
            const py = (Math.cos(progress * 3 + i * 1.5) * 0.5 + 0.5) * canvas.height;
            ctx.beginPath();
            ctx.arc(px, py, 6 + i * 2, 0, Math.PI * 2);
            ctx.fill();
          }

          requestAnimationFrame(drawFrame);
        };
        drawFrame();
      });
    }
  },
  {
    id: 'sample-neon-cyberpunk',
    name: 'Cyberpunk Neon Street',
    category: 'Low-Light & Contrast',
    description: 'High contrast night scene testing shadow cleanup and neon edge sharpness.',
    posterUrl: '/src/assets/images/sample_neon_reel_1793300310807.jpg',
    aspect: '9:16 (1080x1920)',
    generateCanvasVideo: async (canvas: HTMLCanvasElement, durationSeconds = 5) => {
      canvas.width = 720;
      canvas.height = 1280;
      const ctx = canvas.getContext('2d')!;

      const bitmap = await loadSafeBitmap('/src/assets/images/sample_neon_reel_1793300310807.jpg');

      const stream = canvas.captureStream(60);
      const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.start();

      const startTime = performance.now();
      const totalMs = durationSeconds * 1000;

      return new Promise<string>((resolve) => {
        const drawFrame = () => {
          const now = performance.now();
          const progress = (now - startTime) / totalMs;

          if (progress >= 1.0) {
            recorder.stop();
            recorder.onstop = () => {
              const blob = new Blob(chunks, { type: 'video/webm' });
              resolve(URL.createObjectURL(blob));
            };
            return;
          }

          if (bitmap) {
            const panX = Math.sin(progress * Math.PI) * 20;
            ctx.drawImage(bitmap, -20 + panX, 0, canvas.width + 40, canvas.height);

            const flicker = Math.sin(now * 0.05) > 0.8 ? 0.3 : 0.1;
            ctx.fillStyle = `rgba(0, 230, 255, ${flicker})`;
            ctx.fillRect(0, canvas.height * 0.7, canvas.width, canvas.height * 0.3);
          } else {
            const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
            grad.addColorStop(0, '#050505');
            grad.addColorStop(1, '#4f46e5');
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
          }

          requestAnimationFrame(drawFrame);
        };
        drawFrame();
      });
    }
  }
];
