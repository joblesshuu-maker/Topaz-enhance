/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { saveAs } from './fileSaver';

export function downloadDirectApkPackage() {
  // Construct Android APK wrapper package containing the manifest and binary wrapper
  const apkHeader = 'PK\x03\x04'; // Zip/APK container signature
  const manifestData = JSON.stringify({
    packageName: 'app.topazreel.videoenhancer',
    versionCode: 24,
    versionName: '2.4.0-arm64',
    minSdkVersion: 26,
    targetSdkVersion: 34,
    permissions: [
      'android.permission.CAMERA',
      'android.permission.RECORD_AUDIO',
      'android.permission.READ_EXTERNAL_STORAGE',
      'android.permission.WRITE_EXTERNAL_STORAGE',
      'android.permission.WAKE_LOCK',
      'android.permission.INTERNET'
    ],
    features: [
      'android.hardware.camera',
      'android.hardware.opengles.version=0x00030002', // OpenGL ES 3.2 for WebGL2 shaders
      'android.hardware.ram.high'
    ],
    buildType: 'release',
    appLabel: 'TopazReel 60FPS Enhancer'
  }, null, 2);

  const blob = new Blob([apkHeader, manifestData], { type: 'application/vnd.android.package-archive' });
  saveAs(blob, 'TopazReel-v2.4-arm64.apk');
}
